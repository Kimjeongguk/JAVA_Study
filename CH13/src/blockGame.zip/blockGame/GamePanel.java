package blockGame;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;

public class GamePanel extends JPanel implements Runnable {
	static int BALL_DIAMERT = 20;
	static int BLOCK_ROW = 5;
	static int BLOCK_COLUMN = 10;
	static int BLOCK_WIDTH = 60;
	static int BLOCK_HEIGHT = 30;
	static int BLOCK_GAP = 2;
	static int PADDLE_WIDTH = 90;
	static int PADDLE_HEIGHT = 20;
	static int GAME_WIDTH = BLOCK_WIDTH*BLOCK_COLUMN+BLOCK_GAP*(BLOCK_COLUMN-1);
	static int GAME_HEIGHT = 900;
	
	private Ball ball = new Ball();
	private Paddle paddle = new Paddle();
	private Thread th;
	
	private Block blocks[][] = new Block[GamePanel.BLOCK_ROW][GamePanel.BLOCK_COLUMN];
	
	public GamePanel() {
		this.setPreferredSize(new Dimension(GAME_WIDTH,GAME_HEIGHT));
//		this.setSize(GAME_WIDTH,GAME_HEIGHT);
		this.setBackground(Color.BLACK);
		
		
		for(int i=0; i<GamePanel.BLOCK_ROW; i++) {
			for (int j=0; j<GamePanel.BLOCK_COLUMN; j++) {
				blocks[i][j] = new Block();
				blocks[i][j].x = GamePanel.BLOCK_WIDTH*j + GamePanel.BLOCK_GAP*j;
				blocks[i][j].y = 100+GamePanel.BLOCK_HEIGHT*i + GamePanel.BLOCK_GAP*i;
				blocks[i][j].width = GamePanel.BLOCK_WIDTH;
				blocks[i][j].height = GamePanel.BLOCK_HEIGHT;
				blocks[i][j].color = i;
			}
		}
	
		this.setFocusable(true);
		this.requestFocus();
		this.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyReleased(KeyEvent e) {
				switch(e.getKeyCode()) {
				case KeyEvent.VK_LEFT:
					paddle.left = false;
					break;
				case KeyEvent.VK_RIGHT:
					paddle.right = false;
					break;
				}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				switch(e.getKeyCode()) {
				case KeyEvent.VK_LEFT:
					paddle.left = true;
					break;
				case KeyEvent.VK_RIGHT:
					paddle.right = true;
					break;
				}
			}
		});
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.WHITE);
		g.fillOval(ball.x, ball.y, ball.width, ball.height);
		g.setColor(Color.RED);
		g.fillRect(paddle.x, paddle.y, paddle.width, paddle.height);
		
		th = new Thread(this);
		th.start();
		for(int i=0; i<GamePanel.BLOCK_ROW; i++) {
			
			for (int j=0; j<GamePanel.BLOCK_COLUMN; j++) {
				if(blocks[i][j].color == 0) {
					g.setColor(Color.BLUE);
				}else if(blocks[i][j].color == 1){
					g.setColor(Color.GREEN);
				}else if (blocks[i][j].color == 2) {
					g.setColor(Color.MAGENTA);
				}else if (blocks[i][j].color == 3) {
					g.setColor(Color.YELLOW);
				}else if (blocks[i][j].color == 4) {
					g.setColor(Color.WHITE);
				}
				g.fillRect(blocks[i][j].x, blocks[i][j].y, blocks[i][j].width, blocks[i][j].height);
			}
		}
	}
	
	public void paddleMove() {
		if(paddle.left) {
			paddle.x -= 1;
		}
		if(paddle.right) {
			paddle.x += 1;
		}
	}
	
	public void checkWall() {
		if(ball.dir==0) {
			if(ball.y<0) {
				ball.dir=1;
			}
			if(ball.x > GamePanel.GAME_WIDTH - GamePanel.BALL_DIAMERT) {
				ball.dir = 2;
			}
		}else if (ball.dir == 1) {
			if(ball.y > GamePanel.GAME_HEIGHT - GamePanel.BALL_DIAMERT) {
				ball.dir = 0;
			}
			if(ball.y > GamePanel.GAME_WIDTH - GamePanel.BALL_DIAMERT) {
				ball.dir = 3;
			}
		}else if (ball.dir == 2) {
			if(ball.y<0) {
				ball.dir=3;
			}
			if(ball.x < 0) {
				ball.dir = 0;
			}
		}else if (ball.dir == 3) {
			if(ball.y > GamePanel.GAME_HEIGHT - GamePanel.BALL_DIAMERT) {
				ball.dir = 2;
			}
			if(ball.x < 0) {
				ball.dir = 1;
			}
		}
	}
	
	public void ballMove() {
		if (ball.dir == 0) { //up right
			ball.x+=ball.speed;
			ball.y-=ball.speed;
		}else if(ball.dir == 1) { //down right
			ball.x+=ball.speed;
			ball.y+=ball.speed;
		}else if(ball.dir == 2) { //up left
			ball.x-=ball.speed;
			ball.y-=ball.speed;
		}else if(ball.dir == 3) { //down left
			ball.x-=ball.speed;
			ball.y+=ball.speed;
		}
	}

	@Override
	public void run() {
		while(true) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
//			System.out.println("sadf");
			
			paddleMove();
			ballMove();
			checkWall();
			repaint();
		}
	}
}

