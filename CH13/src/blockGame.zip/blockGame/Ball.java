package blockGame;

public class Ball {
	public int x;
	public int y;
	public int width;
	public int height;
	public int dir;
	public int speed;
	
	public Ball() {
		this.x = GamePanel.GAME_WIDTH/2 - GamePanel.BALL_DIAMERT/2;
		this.y = GamePanel.GAME_HEIGHT/2 - GamePanel.BALL_DIAMERT/2;
		this.width = GamePanel.BALL_DIAMERT;
		this.height = GamePanel.BALL_DIAMERT;
		this.speed = 1;
	}
}
